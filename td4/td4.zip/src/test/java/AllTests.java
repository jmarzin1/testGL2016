import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({DictionaryTest.class, DictionaryParserTest.class})

public class AllTests {

}