#include <stdlib.h>
#include <stdio.h>
#include "ppcm.c"

void test(int x, int y, int result) {
  int pc = ppcm(x, y);
  if (pc == result) {
    printf("PASSED\n");
  }
  else {
    printf("FAILED: found %d instead of %d \n", pc, result);
  }
}

int main(int argc, char** argv) {
  if (argc == 4) {
    test(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]));
  }
  else {
    printf("Il faut 3 entiers en paramètres : x, y et résultat\n");
  }
}

