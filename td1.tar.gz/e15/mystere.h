
int upcase_word(char *str);
int upcase_word_2(char *str);
const char *months(int month);
int month_nth(char *month);

enum Triangle {DEGENERE, SCALENE_AIGU, SCALENE_OBTUS, ISOCELE_AIGU, ISOCELE_OBTUS, EQUILATERAL};
enum Triangle triangle(float a, float b, float c);
enum Triangle triangle_2(float a, float b, float c);
